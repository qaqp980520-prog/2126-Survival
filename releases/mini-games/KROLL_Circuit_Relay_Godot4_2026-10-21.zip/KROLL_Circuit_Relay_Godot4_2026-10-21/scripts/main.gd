extends Node2D
## KROLL Circuit Relay: rotate pipe tiles to connect the power source to the extraction gate.

const GRID := 5
const TILE := 92.0
const ORIGIN := Vector2(270, 145)
const UP := 1
const RIGHT := 2
const DOWN := 4
const LEFT := 8

var tiles: Array = []
var path_cells: Array[Vector2i] = []
var moves := 0
var seconds_left := 90.0
var won := false
var lost := false
var best_moves := 0
var message := "旋轉電路板，讓 KROLL 能源從起點抵達撤離門。"

func _ready() -> void:
    _new_puzzle()

func _process(delta: float) -> void:
    if not won and not lost:
        seconds_left = maxf(0.0, seconds_left - delta)
        if seconds_left <= 0.0:
            lost = true
            message = "能源耗盡！按 R 再試一次。"
        queue_redraw()

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, get_viewport_rect().size), Color("#101923"))
    draw_string(ThemeDB.fallback_font, Vector2(34, 48), "KROLL CIRCUIT RELAY", HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color("#83e6ff"))
    draw_string(ThemeDB.fallback_font, Vector2(35, 82), "點擊格子旋轉電路｜將電源連到撤離門｜R：重新開始", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#c2d3df"))
    draw_string(ThemeDB.fallback_font, Vector2(35, 118), "時間：%02d 秒    步數：%d" % [int(ceil(seconds_left)), moves], HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#ffe29a"))
    for y in range(GRID):
        for x in range(GRID):
            var p := ORIGIN + Vector2(x * TILE, y * TILE)
            var rect := Rect2(p, Vector2(TILE - 5, TILE - 5))
            draw_rect(rect, Color("#1d2c3b"), true)
            draw_rect(rect, Color("#3c5264"), false, 2.0)
            var mask: int = int(tiles[y][x])
            _draw_pipe(p + Vector2((TILE - 5) / 2.0, (TILE - 5) / 2.0), mask)
            if x == 0 and y == 0:
                draw_circle(p + Vector2(18, 18), 7, Color("#ffcb63"))
                draw_string(ThemeDB.fallback_font, p + Vector2(6, 78), "POWER", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#ffcb63"))
            if x == GRID - 1 and y == GRID - 1:
                draw_circle(p + Vector2(TILE - 23, TILE - 23), 7, Color("#70f2ba"))
                draw_string(ThemeDB.fallback_font, p + Vector2(2, 78), "EXIT", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#70f2ba"))
    var footer := message
    if won:
        footer = "連線成功！KROLL 能源已送達。步數：%d。按 R 挑戰新電路。" % moves
    elif lost:
        footer = "時間耗盡，能源傳輸失敗。按 R 再試一次。"
    draw_string(ThemeDB.fallback_font, Vector2(35, 690), footer, HORIZONTAL_ALIGNMENT_LEFT, 920, 18, Color("#e8f1f7"))
    draw_string(ThemeDB.fallback_font, Vector2(35, 724), "提示：相鄰格的管線必須彼此接通；不必連接所有格子，只要打通一條路。", HORIZONTAL_ALIGNMENT_LEFT, 920, 14, Color("#91a8b8"))

func _draw_pipe(center: Vector2, mask: int) -> void:
    var color := Color("#78d9ef")
    var thick := 12.0
    draw_circle(center, thick * 0.68, color)
    if mask & UP:
        draw_line(center, center + Vector2(0, -31), color, thick, true)
    if mask & RIGHT:
        draw_line(center, center + Vector2(31, 0), color, thick, true)
    if mask & DOWN:
        draw_line(center, center + Vector2(0, 31), color, thick, true)
    if mask & LEFT:
        draw_line(center, center + Vector2(-31, 0), color, thick, true)

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_R:
        _new_puzzle()
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        if won or lost:
            return
        var local := event.position - ORIGIN
        var x := int(floor(local.x / TILE))
        var y := int(floor(local.y / TILE))
        if x >= 0 and x < GRID and y >= 0 and y < GRID and local.x >= 0 and local.y >= 0:
            tiles[y][x] = _rotate_mask(int(tiles[y][x]))
            moves += 1
            _check_connection()
            queue_redraw()

func _rotate_mask(mask: int) -> int:
    var out := 0
    if mask & UP: out |= RIGHT
    if mask & RIGHT: out |= DOWN
    if mask & DOWN: out |= LEFT
    if mask & LEFT: out |= UP
    return out

func _new_puzzle() -> void:
    won = false
    lost = false
    moves = 0
    seconds_left = 90.0
    tiles.clear()
    path_cells.clear()
    for y in range(GRID):
        var row: Array[int] = []
        for x in range(GRID):
            row.append(0)
        tiles.append(row)
    # Build a guaranteed source-to-exit route using a random mixture of right/down steps.
    var cur := Vector2i(0, 0)
    path_cells.append(cur)
    while cur.x < GRID - 1 or cur.y < GRID - 1:
        var can_right := cur.x < GRID - 1
        var can_down := cur.y < GRID - 1
        if can_right and can_down:
            if randf() < 0.5:
                cur.x += 1
            else:
                cur.y += 1
        elif can_right:
            cur.x += 1
        else:
            cur.y += 1
        path_cells.append(cur)
    for i in range(path_cells.size()):
        var cell: Vector2i = path_cells[i]
        var mask := 0
        if i > 0:
            var prev: Vector2i = path_cells[i - 1]
            mask |= _direction_between(cell, prev)
        if i < path_cells.size() - 1:
            var nxt: Vector2i = path_cells[i + 1]
            mask |= _direction_between(cell, nxt)
        tiles[cell.y][cell.x] = mask
    # Scramble every cell independently; unused cells become plausible elbows/straights.
    for y in range(GRID):
        for x in range(GRID):
            if tiles[y][x] == 0:
                tiles[y][x] = [UP | DOWN, LEFT | RIGHT, UP | RIGHT, RIGHT | DOWN, DOWN | LEFT, LEFT | UP][randi_range(0, 5)]
            var turns := randi_range(0, 3)
            for j in range(turns):
                tiles[y][x] = _rotate_mask(int(tiles[y][x]))
    # Ensure at least some puzzle work is needed.
    for i in range(4):
        var cell: Vector2i = path_cells[randi_range(0, path_cells.size() - 1)]
        tiles[cell.y][cell.x] = _rotate_mask(int(tiles[cell.y][cell.x]))
    message = "重新佈線：旋轉管線，建立從左上電源到右下撤離門的連通路徑。"
    queue_redraw()

func _direction_between(a: Vector2i, b: Vector2i) -> int:
    var d := b - a
    if d == Vector2i(0, -1): return UP
    if d == Vector2i(1, 0): return RIGHT
    if d == Vector2i(0, 1): return DOWN
    return LEFT

func _check_connection() -> void:
    var seen: Dictionary = {}
    var stack: Array[Vector2i] = [Vector2i(0, 0)]
    while not stack.is_empty():
        var cell: Vector2i = stack.pop_back()
        if seen.has(cell):
            continue
        seen[cell] = true
        if cell == Vector2i(GRID - 1, GRID - 1):
            won = true
            message = "連線成功！"
            return
        var mask: int = int(tiles[cell.y][cell.x])
        var dirs := [
            {"bit": UP, "delta": Vector2i(0, -1), "opp": DOWN},
            {"bit": RIGHT, "delta": Vector2i(1, 0), "opp": LEFT},
            {"bit": DOWN, "delta": Vector2i(0, 1), "opp": UP},
            {"bit": LEFT, "delta": Vector2i(-1, 0), "opp": RIGHT}
        ]
        for d in dirs:
            if mask & int(d["bit"]) == 0:
                continue
            var next: Vector2i = cell + d["delta"]
            if next.x < 0 or next.x >= GRID or next.y < 0 or next.y >= GRID:
                continue
            var next_mask: int = int(tiles[next.y][next.x])
            if next_mask & int(d["opp"]) != 0 and not seen.has(next):
                stack.append(next)
    message = "還沒連通。檢查每個相鄰格的管線方向。"
